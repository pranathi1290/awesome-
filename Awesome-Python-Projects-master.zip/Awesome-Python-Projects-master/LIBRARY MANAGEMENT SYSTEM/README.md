# Library Management System | Python & PyQt5

    - adding new books
    - adding books categories
    - adding books Author
    - adding books Publisher
    - adding day to day operations for rent or retrieving books
    - Generate Excel reports from our data
    - Adding new users with user login  and editing user data


-What you’ll learn
    - Installing Python
    - Installing PyQt5
    - Installing MySQL Server
    - Design nice desktop applications with QtDesigner
    - Styling desktop applications with CSS
    - Design a database using mysql workbench
    - Connecting to mysql database with python
    - inserting , selecting , updating , deleting database data from our app
    - Adding project themes and change between them easly
    - Adding new users
    - Updating user data
    - Login at startup
