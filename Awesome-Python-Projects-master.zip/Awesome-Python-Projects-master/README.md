<div align="center">
<h1>Awesome Python Projects</h1>
<h3>A Curated List of Awesome projects made with Python.</h3>
  
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com)
[![GitHub forks](https://img.shields.io/github/forks/saadhaxxan/Awesome-Python-Projects.svg?style=social&label=Fork&maxAge=2592000)](https://github.com/saadhaxxan/Awesome-Python-Projects/network/)
[![GitHub stars](https://img.shields.io/github/stars/saadhaxxan/Awesome-Python-Projects.svg?style=social&label=Star&maxAge=2592000)](https://GitHub.com/saadhaxxan/Awesome-Python-Projects/stargazers/)
[![PyPI pyversions](https://img.shields.io/pypi/pyversions/ansicolortags.svg)](https://pypi.python.org/pypi/ansicolortags/)
[![GitHub Issues](https://img.shields.io/github/issues/saadhaxxan/Visual-and-EDA-of-Corona-Virus.svg?style=flat&label=Issues&maxAge=2592000)](https://github.com/saadhaxxan/Awesome-Python-Projetcs/issues)
[![Open Source Love png3](https://badges.frapsoft.com/os/v3/open-source.png?v=103)](https://github.com/ellerbrock/open-source-badges/)
[![MIT license](https://img.shields.io/badge/License-MIT-blue.svg)](https://lbesson.mit-license.org/)
</div>

## Author
You can get in touch with me on my LinkedIn Profile:

#### Saad Hassan
[![LinkedIn Link](https://img.shields.io/badge/Connect-saadhaxxan-blue.svg?logo=linkedin&longCache=true&style=social&label=Connect
)](https://www.linkedin.com/in/saadhaxxan)

You can also follow my GitHub Profile to stay updated about my latest projects: [![GitHub Follow](https://img.shields.io/badge/Connect-saadhaxxan-blue.svg?logo=Github&longCache=true&style=social&label=Follow)](https://github.com/saadhaxxan)

If you liked the repo then kindly support it by giving it a star ⭐!

## Contributions Welcome
[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](#)

If you find any bug in the code or have any improvements in mind then feel free to generate a pull request.


## LICENSE
- MIT (2021)
